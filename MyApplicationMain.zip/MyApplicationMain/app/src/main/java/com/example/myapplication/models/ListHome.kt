package com.example.myapplication.models

import android.graphics.drawable.Drawable

data class ListHome(
    var account: String,
    var hospitalName: String,
    var hospitalImage: Drawable
)
