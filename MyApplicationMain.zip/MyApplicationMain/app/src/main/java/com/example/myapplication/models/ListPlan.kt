package com.example.myapplication.models

import java.io.Serializable

data class ListPlan(
    var title: String,
    var account: String
) : Serializable
